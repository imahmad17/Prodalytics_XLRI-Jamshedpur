# Prodalytics_XLRI-Jamshedpur
This respository is made by the members of team Blood Group Data, finalists in Prodalytics competition organised by XLRI Jamshedpur in 2023
